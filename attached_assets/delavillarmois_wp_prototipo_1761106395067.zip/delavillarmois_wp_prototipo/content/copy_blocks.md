
# De la Villarmois – Tecnología y Futuro Laboral

## Hero (HTML para bloque "Cubierta" o "Grupo")
```
<!-- wp:cover {"overlayColor":"azul-profundo","minHeight":70,"minHeightUnit":"vh","isDark":true} -->
<div class="wp-block-cover is-dark" style="min-height:70vh"><span aria-hidden="true" class="wp-block-cover__background has-azul-profundo-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:image {"align":"left","sizeSlug":"large"} -->
<figure class="wp-block-image alignleft size-large"><img src="[SUBE-ESTE-LOGO-URL]" alt="De la Villarmois – Tecnología y Futuro Laboral"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"left","level":1,"textColor":"white"} -->
<h1 class="has-text-align-left has-white-color has-text-color">Tecnología, educación e innovación para el futuro del trabajo</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"white"} -->
<p class="has-white-color has-text-color">Acompañamos a instituciones y equipos a integrar inteligencia artificial y herramientas digitales con enfoque humano, ético y medible.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"backgroundColor":"cian-acento","textColor":"azul-profundo"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-azul-profundo-color has-cian-acento-background-color has-text-color has-background wp-element-button" href="#contacto">Agendar consulta</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div></div>
<!-- /wp:cover -->
```

## Sección: IA en números (3 columnas)
```
<!-- wp:columns {"className":"section-kpis"} -->
<div class="wp-block-columns section-kpis"><!-- wp:column -->
<div class="wp-block-column"><p class="number">37%</p><p>de tareas administrativas pueden automatizarse en educación.</p></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><p class="number">60%</p><p>de empleos incorporarán IA como apoyo en la próxima década.</p></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><p class="number">3x</p><p>mejora en tiempos de diseño curricular con flujos asistidos.</p></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
```

## Sección: Servicios/tecnología (íconos + texto)
```
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3>Aprendizaje automatizado</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Modelos de recomendación de contenidos y evaluación adaptativa.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3>Herramientas en el aula</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flujos de trabajo prácticos con herramientas accesibles para docentes y estudiantes.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3>Ética y transformación</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Políticas de uso responsable, privacidad y enfoque humano en cada implementación.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
```

## Aliados (logos simulados)
```
<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3>Nuestros aliados</h3>
<!-- /wp:heading -->

<!-- wp:gallery {"columns":4} -->
<figure class="wp-block-gallery has-nested-images columns-4 is-cropped">
<!-- wp:image {"id":0,"sizeSlug":"thumbnail"} --><figure class="wp-block-image size-thumbnail"><img src="[SUBE-LOGO-1]" alt="Aliado 1"/></figure><!-- /wp:image -->
<!-- wp:image {"id":0,"sizeSlug":"thumbnail"} --><figure class="wp-block-image size-thumbnail"><img src="[SUBE-LOGO-2]" alt="Aliado 2"/></figure><!-- /wp:image -->
<!-- wp:image {"id":0,"sizeSlug":"thumbnail"} --><figure class="wp-block-image size-thumbnail"><img src="[SUBE-LOGO-3]" alt="Aliado 3"/></figure><!-- /wp:image -->
<!-- wp:image {"id":0,"sizeSlug":"thumbnail"} --><figure class="wp-block-image size-thumbnail"><img src="[SUBE-LOGO-4]" alt="Aliado 4"/></figure><!-- /wp:image -->
</figure>
<!-- /wp:gallery --></div>
<!-- /wp:group -->
```

## Carreras (llamados a la acción)
```
<!-- wp:group -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3>Oportunidades</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul><li>Investigación y datos</li><li>Desarrollo de IA educativa</li><li>Diseño de experiencias de aprendizaje</li></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"backgroundColor":"cian-acento","textColor":"azul-profundo"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-azul-profundo-color has-cian-acento-background-color has-text-color has-background wp-element-button" href="#contacto">Aplicar ahora</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
```

## Portafolio (rejilla)
```
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"large"} --><figure class="wp-block-image size-large"><img src="[IMG1]" alt="Proyecto 1"/></figure><!-- /wp:image --><p><strong>IA en el aula</strong> – Pilotaje de herramientas de apoyo docente.</p></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"large"} --><figure class="wp-block-image size-large"><img src="[IMG2]" alt="Proyecto 2"/></figure><!-- /wp:image --><p><strong>Aprendizaje adaptativo</strong> – Rutas personalizadas por desempeño.</p></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"large"} --><figure class="wp-block-image size-large"><img src="[IMG3]" alt="Proyecto 3"/></figure><!-- /wp:image --><p><strong>Simulación cognitiva</strong> – Talleres de razonamiento asistido.</p></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
```

## Blog (tarjetas)
```
<!-- wp:query {"query":{"perPage":3},"displayLayout":{"type":"grid","columns":3}} -->
<div class="wp-block-query"><!-- wp:post-template -->
<!-- wp:group -->
<div class="wp-block-group"><!-- wp:post-title {"isLink":true} /-->
<!-- wp:post-excerpt /-->
<!-- wp:post-date /--></div>
<!-- /wp:group -->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
```

## Contacto (ancla)
```
<!-- wp:group {"anchor":"contacto"} -->
<div class="wp-block-group" id="contacto"><!-- wp:heading {"level":3} -->
<h3>Contacto</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Escríbenos y conversemos cómo impulsar tu proyecto con tecnología responsable.</p>
<!-- /wp:paragraph -->

<!-- wp:contact-form-7 /-->
<!-- Si estás en WordPress.com Gratuito (sin plugins), usa el bloque "Formulario" nativo -->
</div>
<!-- /wp:group -->
```
